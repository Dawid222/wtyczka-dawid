def classFactory(iface):
    from .plugin import PolskaMapaOSM
    return PolskaMapaOSM(iface)
