from qgis.PyQt.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QHBoxLayout,
    QToolBar,
    QStatusBar,
    QLabel,
    QAction,
)
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QIcon
from qgis.core import (
    QgsRasterLayer,
    QgsProject,
    QgsRectangle,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
)
from qgis.gui import (
    QgsMapCanvas,
    QgsMapToolPan,
    QgsMapToolZoom,
    QgsMapToolEmitPoint,
)


# Granice Polski (EPSG:4326 - WGS84)
POLSKA_WEST = 14.07
POLSKA_SOUTH = 49.0
POLSKA_EAST = 24.15
POLSKA_NORTH = 54.84

# CRS dla kafelków OSM
OSM_CRS = QgsCoordinateReferenceSystem("EPSG:3857")
WGS84_CRS = QgsCoordinateReferenceSystem("EPSG:4326")


class ClickTool(QgsMapToolEmitPoint):
    """Narzędzie do klikania na mapę i odczytywania współrzędnych."""

    def __init__(self, canvas, callback):
        super().__init__(canvas)
        self.callback = callback

    def canvasReleaseEvent(self, event):
        point = self.toMapCoordinates(event.pos())
        self.callback(point)


class MapDialog(QDialog):
    """Okno dialogowe z interaktywną mapą OSM ograniczoną do Polski."""

    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.setWindowTitle("Polska Mapa OSM")
        self.resize(1000, 750)
        self.setMinimumSize(600, 400)

        self._setup_ui()
        self._load_osm_layer()
        self._zoom_to_poland()
        self._activate_pan()

    def _setup_ui(self):
        """Budowanie interfejsu okna."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # --- Toolbar ---
        self.toolbar = QToolBar("Narzędzia mapy", self)
        self.toolbar.setMovable(False)

        self.action_pan = QAction("✋ Przesuń", self)
        self.action_pan.setCheckable(True)
        self.action_pan.setToolTip("Przesuń mapę (przeciągnij)")
        self.action_pan.triggered.connect(self._activate_pan)

        self.action_zoom_in = QAction("🔍+ Przybliż", self)
        self.action_zoom_in.setCheckable(True)
        self.action_zoom_in.setToolTip("Przybliż (zaznacz obszar)")
        self.action_zoom_in.triggered.connect(self._activate_zoom_in)

        self.action_zoom_out = QAction("🔍− Oddal", self)
        self.action_zoom_out.setCheckable(True)
        self.action_zoom_out.setToolTip("Oddal (kliknij na mapę)")
        self.action_zoom_out.triggered.connect(self._activate_zoom_out)

        self.action_click = QAction("📍 Współrzędne", self)
        self.action_click.setCheckable(True)
        self.action_click.setToolTip("Kliknij na mapę, aby odczytać współrzędne")
        self.action_click.triggered.connect(self._activate_click)

        self.action_home = QAction("🇵🇱 Polska", self)
        self.action_home.setToolTip("Wróć do widoku całej Polski")
        self.action_home.triggered.connect(self._zoom_to_poland)

        self.toolbar.addAction(self.action_pan)
        self.toolbar.addAction(self.action_zoom_in)
        self.toolbar.addAction(self.action_zoom_out)
        self.toolbar.addAction(self.action_click)
        self.toolbar.addSeparator()
        self.toolbar.addAction(self.action_home)

        self._tool_actions = [
            self.action_pan,
            self.action_zoom_in,
            self.action_zoom_out,
            self.action_click,
        ]

        layout.addWidget(self.toolbar)

        # --- Mapa ---
        self.canvas = QgsMapCanvas(self)
        self.canvas.setCanvasColor(Qt.white)
        self.canvas.setDestinationCrs(OSM_CRS)
        self.canvas.enableAntiAliasing(True)
        layout.addWidget(self.canvas)

        # --- Status bar ---
        self.statusbar = QStatusBar(self)
        self.coord_label = QLabel("Gotowe")
        self.statusbar.addPermanentWidget(self.coord_label)
        layout.addWidget(self.statusbar)

        # --- Narzędzia mapy ---
        self.tool_pan = QgsMapToolPan(self.canvas)
        self.tool_zoom_in = QgsMapToolZoom(self.canvas, False)  # False = zoom in
        self.tool_zoom_out = QgsMapToolZoom(self.canvas, True)  # True = zoom out
        self.tool_click = ClickTool(self.canvas, self._on_map_click)

        # Śledzenie ruchu kursora — wyświetlaj współrzędne w statusbar
        self.canvas.xyCoordinates.connect(self._on_mouse_move)

    def _load_osm_layer(self):
        """Ładuje warstwę kafelków OpenStreetMap."""
        uri = (
            "type=xyz"
            "&url=https://tile.openstreetmap.org/{z}/{x}/{y}.png"
            "&zmax=19&zmin=0"
            "&crs=EPSG:3857"
        )
        self.osm_layer = QgsRasterLayer(uri, "OpenStreetMap", "wms")
        if self.osm_layer.isValid():
            QgsProject.instance().addMapLayer(self.osm_layer, False)
            self.canvas.setLayers([self.osm_layer])
        else:
            self.statusbar.showMessage(
                "Błąd: nie udało się załadować warstwy OSM", 5000
            )

    def _get_poland_extent_3857(self):
        """Zwraca zasięg Polski przekształcony do EPSG:3857."""
        extent_4326 = QgsRectangle(
            POLSKA_WEST, POLSKA_SOUTH, POLSKA_EAST, POLSKA_NORTH
        )
        transform = QgsCoordinateTransform(
            WGS84_CRS, OSM_CRS, QgsProject.instance()
        )
        return transform.transformBoundingBox(extent_4326)

    def _zoom_to_poland(self):
        """Ustawia widok mapy na cały obszar Polski."""
        extent = self._get_poland_extent_3857()
        self.canvas.setExtent(extent)
        self.canvas.refresh()
        self.statusbar.showMessage("Widok: cała Polska", 3000)

    # --- Aktywacja narzędzi ---

    def _set_checked(self, active_action):
        """Odznacza wszystkie narzędzia poza wybranym."""
        for action in self._tool_actions:
            action.setChecked(action is active_action)

    def _activate_pan(self):
        self.canvas.setMapTool(self.tool_pan)
        self._set_checked(self.action_pan)
        self.statusbar.showMessage("Narzędzie: przesuwanie mapy", 2000)

    def _activate_zoom_in(self):
        self.canvas.setMapTool(self.tool_zoom_in)
        self._set_checked(self.action_zoom_in)
        self.statusbar.showMessage("Narzędzie: przybliżanie (zaznacz obszar)", 2000)

    def _activate_zoom_out(self):
        self.canvas.setMapTool(self.tool_zoom_out)
        self._set_checked(self.action_zoom_out)
        self.statusbar.showMessage("Narzędzie: oddalanie (kliknij na mapę)", 2000)

    def _activate_click(self):
        self.canvas.setMapTool(self.tool_click)
        self._set_checked(self.action_click)
        self.statusbar.showMessage(
            "Narzędzie: kliknij na mapę, aby odczytać współrzędne", 2000
        )

    # --- Obsługa zdarzeń mapy ---

    def _on_map_click(self, point_3857):
        """Obsługuje kliknięcie na mapę — wyświetla współrzędne WGS84."""
        transform = QgsCoordinateTransform(
            OSM_CRS, WGS84_CRS, QgsProject.instance()
        )
        point_4326 = transform.transform(point_3857)
        text = f"📍 Kliknięto: {point_4326.y():.6f}°N, {point_4326.x():.6f}°E"
        self.coord_label.setText(text)
        self.statusbar.showMessage(text, 10000)

    def _on_mouse_move(self, point):
        """Aktualizuje współrzędne kursora w statusbar."""
        if self.canvas.mapTool() is not self.tool_click:
            transform = QgsCoordinateTransform(
                OSM_CRS, WGS84_CRS, QgsProject.instance()
            )
            point_4326 = transform.transform(point)
            self.coord_label.setText(
                f"{point_4326.y():.5f}°N, {point_4326.x():.5f}°E"
            )

    def closeEvent(self, event):
        """Sprzątanie przy zamykaniu okna."""
        if hasattr(self, "osm_layer") and self.osm_layer:
            QgsProject.instance().removeMapLayer(self.osm_layer.id())
        super().closeEvent(event)
