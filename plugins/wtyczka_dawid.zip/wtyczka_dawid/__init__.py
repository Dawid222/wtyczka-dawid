def classFactory(iface):
    from .plugin import WtyczkaDawid
    return WtyczkaDawid(iface)
