from qgis.PyQt.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QToolBar,
    QStatusBar,
    QLabel,
    QAction,
    QComboBox,
    QProgressBar,
)
from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal
from qgis.core import (
    QgsRasterLayer,
    QgsVectorLayer,
    QgsProject,
    QgsRectangle,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsFeatureRequest,
    QgsGeometry,
    QgsPointXY,
    QgsFillSymbol,
    QgsSingleSymbolRenderer,
)
from qgis.gui import (
    QgsMapCanvas,
    QgsMapToolPan,
    QgsMapToolZoom,
    QgsMapToolEmitPoint,
)


# Granice Polski (EPSG:4326 - WGS84)
POLSKA_WEST = 14.07
POLSKA_SOUTH = 49.0
POLSKA_EAST = 24.15
POLSKA_NORTH = 54.84

# CRS
OSM_CRS = QgsCoordinateReferenceSystem("EPSG:3857")
WGS84_CRS = QgsCoordinateReferenceSystem("EPSG:4326")

# WFS URL dla powiatów z GUGiK PRG
WFS_POWIATY_URL = (
    "https://mapy.geoportal.gov.pl/wss/service/PZGIK/PRG/WFS/AdministrativeBoundaries?"
    "SERVICE=WFS&VERSION=2.0.0&REQUEST=GetFeature"
    "&TYPENAMES=A02_Granice_powiatow"
    "&SRSNAME=urn:ogc:def:crs:EPSG::2180"
    "&COUNT=500"
)


class WfsLoaderThread(QThread):
    """Watek do pobierania danych WFS w tle."""
    finished = pyqtSignal(bool, str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.layer = None

    def run(self):
        try:
            uri = f"url={WFS_POWIATY_URL}"
            self.layer = QgsVectorLayer(uri, "Powiaty", "WFS")
            if self.layer.isValid() and self.layer.featureCount() > 0:
                self.finished.emit(True, "")
            else:
                self.finished.emit(False, "Warstwa WFS jest pusta lub nieprawidlowa")
        except Exception as e:
            self.finished.emit(False, str(e))


class ClickTool(QgsMapToolEmitPoint):
    """Narzedzie do klikania na mape."""

    def __init__(self, canvas, callback):
        super().__init__(canvas)
        self.callback = callback

    def canvasReleaseEvent(self, event):
        point = self.toMapCoordinates(event.pos())
        self.callback(point)


class MapDialog(QDialog):
    """Okno dialogowe z interaktywna mapa OSM + powiaty."""

    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.setWindowTitle("Wtyczka Dawid")
        self.resize(1100, 800)
        self.setMinimumSize(700, 500)

        self.osm_layer = None
        self.powiaty_layer = None
        self.selected_powiat = None
        self.powiaty_loaded = False

        self._setup_ui()
        self._load_osm_layer()
        self._zoom_to_poland()
        self._activate_pan()
        self._start_loading_powiaty()

    def _setup_ui(self):
        """Budowanie interfejsu okna."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # --- Toolbar ---
        self.toolbar = QToolBar("Narzedzia mapy", self)
        self.toolbar.setMovable(False)

        self.action_pan = QAction("Pan", self)
        self.action_pan.setCheckable(True)
        self.action_pan.setToolTip("Przesun mape (przeciagnij)")
        self.action_pan.triggered.connect(self._activate_pan)

        self.action_zoom_in = QAction("Zoom +", self)
        self.action_zoom_in.setCheckable(True)
        self.action_zoom_in.setToolTip("Przybliz (zaznacz obszar)")
        self.action_zoom_in.triggered.connect(self._activate_zoom_in)

        self.action_zoom_out = QAction("Zoom -", self)
        self.action_zoom_out.setCheckable(True)
        self.action_zoom_out.setToolTip("Oddal (kliknij na mape)")
        self.action_zoom_out.triggered.connect(self._activate_zoom_out)

        self.action_select = QAction("Wybierz powiat", self)
        self.action_select.setCheckable(True)
        self.action_select.setToolTip("Kliknij na mape, aby wybrac powiat")
        self.action_select.triggered.connect(self._activate_select)

        self.action_home = QAction("Polska", self)
        self.action_home.setToolTip("Wroc do widoku calej Polski")
        self.action_home.triggered.connect(self._reset_view)

        self.toolbar.addAction(self.action_pan)
        self.toolbar.addAction(self.action_zoom_in)
        self.toolbar.addAction(self.action_zoom_out)
        self.toolbar.addAction(self.action_select)
        self.toolbar.addSeparator()
        self.toolbar.addAction(self.action_home)

        self._tool_actions = [
            self.action_pan,
            self.action_zoom_in,
            self.action_zoom_out,
            self.action_select,
        ]

        # --- Lista powiatow ---
        self.toolbar.addSeparator()
        powiat_label = QLabel("  Powiat: ")
        self.toolbar.addWidget(powiat_label)

        self.combo_powiaty = QComboBox()
        self.combo_powiaty.setMinimumWidth(200)
        self.combo_powiaty.setEnabled(False)
        self.combo_powiaty.addItem("Ladowanie powiatow...")
        self.combo_powiaty.currentIndexChanged.connect(self._on_combo_changed)
        self.toolbar.addWidget(self.combo_powiaty)

        layout.addWidget(self.toolbar)

        # --- Pasek postepu ---
        self.progress = QProgressBar(self)
        self.progress.setMaximum(0)
        self.progress.setTextVisible(True)
        self.progress.setFormat("Pobieranie granic powiatow z GUGiK...")
        layout.addWidget(self.progress)

        # --- Mapa ---
        self.canvas = QgsMapCanvas(self)
        self.canvas.setCanvasColor(Qt.white)
        self.canvas.setDestinationCrs(OSM_CRS)
        self.canvas.enableAntiAliasing(True)
        layout.addWidget(self.canvas)

        # --- Status bar ---
        self.statusbar = QStatusBar(self)
        self.coord_label = QLabel("Gotowe")
        self.statusbar.addPermanentWidget(self.coord_label)
        layout.addWidget(self.statusbar)

        # --- Narzedzia mapy ---
        self.tool_pan = QgsMapToolPan(self.canvas)
        self.tool_zoom_in = QgsMapToolZoom(self.canvas, False)
        self.tool_zoom_out = QgsMapToolZoom(self.canvas, True)
        self.tool_select = ClickTool(self.canvas, self._on_map_click_select)

        self.canvas.xyCoordinates.connect(self._on_mouse_move)

    def _load_osm_layer(self):
        """Laduje warstwe OpenStreetMap."""
        uri = (
            "type=xyz"
            "&url=https://tile.openstreetmap.org/{z}/{x}/{y}.png"
            "&zmax=19&zmin=0"
            "&crs=EPSG:3857"
        )
        self.osm_layer = QgsRasterLayer(uri, "OpenStreetMap", "wms")
        if self.osm_layer.isValid():
            QgsProject.instance().addMapLayer(self.osm_layer, False)
        else:
            self.statusbar.showMessage("Blad: nie udalo sie zaladowac OSM", 5000)

    def _start_loading_powiaty(self):
        """Rozpoczyna pobieranie powiatow w tle."""
        self.wfs_thread = WfsLoaderThread(self)
        self.wfs_thread.finished.connect(self._on_powiaty_loaded)
        self.wfs_thread.start()

    def _on_powiaty_loaded(self, success, error_msg):
        """Callback po zaladowaniu powiatow z WFS."""
        self.progress.hide()

        if success and self.wfs_thread.layer:
            self.powiaty_layer = self.wfs_thread.layer
            QgsProject.instance().addMapLayer(self.powiaty_layer, False)

            self._style_powiaty_layer()
            self._refresh_layers()
            self._populate_combo()

            self.powiaty_loaded = True
            self.statusbar.showMessage(
                f"Zaladowano {self.powiaty_layer.featureCount()} powiatow", 5000
            )
        else:
            self.statusbar.showMessage(
                f"Nie udalo sie pobrac powiatow: {error_msg}", 10000
            )
            self.combo_powiaty.clear()
            self.combo_powiaty.addItem("Blad ladowania powiatow")

    def _style_powiaty_layer(self):
        """Nadaje styl warstwie powiatow."""
        if not self.powiaty_layer:
            return
        symbol = QgsFillSymbol.createSimple({
            "color": "30,120,180,40",
            "outline_color": "30,80,150,180",
            "outline_width": "0.5",
        })
        self.powiaty_layer.setRenderer(QgsSingleSymbolRenderer(symbol))
        self.powiaty_layer.triggerRepaint()

    def _refresh_layers(self):
        """Odswieza liste warstw na canvasie."""
        layers = []
        if self.powiaty_layer and self.powiaty_layer.isValid():
            layers.append(self.powiaty_layer)
        if self.osm_layer and self.osm_layer.isValid():
            layers.append(self.osm_layer)
        self.canvas.setLayers(layers)
        self.canvas.refresh()

    def _populate_combo(self):
        """Wypelnia liste rozwijana nazwami powiatow."""
        self.combo_powiaty.blockSignals(True)
        self.combo_powiaty.clear()
        self.combo_powiaty.addItem("-- wybierz powiat --", None)

        powiaty = []
        for feature in self.powiaty_layer.getFeatures():
            name = self._get_feature_name(feature)
            if name:
                powiaty.append((name, feature.id()))

        powiaty.sort(key=lambda x: x[0])

        for name, fid in powiaty:
            self.combo_powiaty.addItem(name, fid)

        self.combo_powiaty.setEnabled(True)
        self.combo_powiaty.blockSignals(False)

    def _get_feature_name(self, feature):
        """Pobiera nazwe powiatu z feature."""
        for attr_name in ["JPT_NAZWA_", "jpt_nazwa_", "nazwa", "NAME", "name",
                          "JPT_NAZWA", "jpt_nazwa"]:
            idx = self.powiaty_layer.fields().indexOf(attr_name)
            if idx >= 0:
                val = feature.attribute(idx)
                if val:
                    return str(val)
        # Fallback
        for i in range(self.powiaty_layer.fields().count()):
            val = feature.attribute(i)
            if isinstance(val, str) and len(val) > 1:
                return val
        return None

    def _get_poland_extent_3857(self):
        extent_4326 = QgsRectangle(
            POLSKA_WEST, POLSKA_SOUTH, POLSKA_EAST, POLSKA_NORTH
        )
        transform = QgsCoordinateTransform(
            WGS84_CRS, OSM_CRS, QgsProject.instance()
        )
        return transform.transformBoundingBox(extent_4326)

    def _zoom_to_poland(self):
        extent = self._get_poland_extent_3857()
        self.canvas.setExtent(extent)
        self.canvas.refresh()

    def _reset_view(self):
        """Resetuje widok i zaznaczenie."""
        self.selected_powiat = None
        if self.powiaty_layer:
            self.powiaty_layer.removeSelection()
            self._style_powiaty_layer()
            self._refresh_layers()
        self._zoom_to_poland()
        self.combo_powiaty.blockSignals(True)
        self.combo_powiaty.setCurrentIndex(0)
        self.combo_powiaty.blockSignals(False)
        self.statusbar.showMessage("Widok: cala Polska", 3000)

    # --- Wybor powiatu ---

    def _select_powiat_by_id(self, feature_id):
        """Zaznacza powiat i przybliza do jego granic."""
        if not self.powiaty_layer:
            return

        feature = None
        for f in self.powiaty_layer.getFeatures(QgsFeatureRequest(feature_id)):
            feature = f
            break

        if not feature:
            return

        self.selected_powiat = feature
        self.powiaty_layer.selectByIds([feature_id])

        # Przybliz do granic powiatu
        geom = feature.geometry()
        bbox = geom.boundingBox()

        layer_crs = self.powiaty_layer.crs()
        transform = QgsCoordinateTransform(
            layer_crs, OSM_CRS, QgsProject.instance()
        )
        bbox_3857 = transform.transformBoundingBox(bbox)
        bbox_3857.scale(1.15)

        self.canvas.setExtent(bbox_3857)
        self.canvas.refresh()

        name = self._get_feature_name(feature) or "Nieznany"
        self.statusbar.showMessage(f"Wybrany powiat: {name}", 10000)

    def _on_map_click_select(self, point_3857):
        """Obsluguje klikniecie na mape — szuka powiatu pod kursorem."""
        if not self.powiaty_loaded or not self.powiaty_layer:
            self.statusbar.showMessage("Powiaty jeszcze sie laduja...", 3000)
            return

        layer_crs = self.powiaty_layer.crs()
        transform = QgsCoordinateTransform(
            OSM_CRS, layer_crs, QgsProject.instance()
        )
        point_layer = transform.transform(point_3857)

        # Bounding box do wstepnego filtrowania
        buff = self.canvas.mapUnitsPerPixel() * 5
        search_rect_3857 = QgsRectangle(
            point_3857.x() - buff,
            point_3857.y() - buff,
            point_3857.x() + buff,
            point_3857.y() + buff,
        )
        transform_rect = QgsCoordinateTransform(
            OSM_CRS, layer_crs, QgsProject.instance()
        )
        search_rect_layer = transform_rect.transformBoundingBox(search_rect_3857)

        request = QgsFeatureRequest().setFilterRect(search_rect_layer)
        point_geom = QgsGeometry.fromPointXY(point_layer)

        for feature in self.powiaty_layer.getFeatures(request):
            if feature.geometry().contains(point_geom):
                self._select_powiat_by_id(feature.id())

                name = self._get_feature_name(feature)
                if name:
                    idx = self.combo_powiaty.findText(name)
                    if idx >= 0:
                        self.combo_powiaty.blockSignals(True)
                        self.combo_powiaty.setCurrentIndex(idx)
                        self.combo_powiaty.blockSignals(False)
                return

        self.statusbar.showMessage("Nie znaleziono powiatu w tym miejscu", 3000)

    def _on_combo_changed(self, index):
        """Obsluguje wybor powiatu z listy rozwijanej."""
        if index <= 0:
            return
        feature_id = self.combo_powiaty.currentData()
        if feature_id is not None:
            self._select_powiat_by_id(feature_id)

    # --- Aktywacja narzedzi ---

    def _set_checked(self, active_action):
        for action in self._tool_actions:
            action.setChecked(action is active_action)

    def _activate_pan(self):
        self.canvas.setMapTool(self.tool_pan)
        self._set_checked(self.action_pan)
        self.statusbar.showMessage("Narzedzie: przesuwanie mapy", 2000)

    def _activate_zoom_in(self):
        self.canvas.setMapTool(self.tool_zoom_in)
        self._set_checked(self.action_zoom_in)
        self.statusbar.showMessage("Narzedzie: przyblizanie", 2000)

    def _activate_zoom_out(self):
        self.canvas.setMapTool(self.tool_zoom_out)
        self._set_checked(self.action_zoom_out)
        self.statusbar.showMessage("Narzedzie: oddalanie", 2000)

    def _activate_select(self):
        self.canvas.setMapTool(self.tool_select)
        self._set_checked(self.action_select)
        self.statusbar.showMessage("Kliknij na mape, aby wybrac powiat", 2000)

    # --- Kursor ---

    def _on_mouse_move(self, point):
        transform = QgsCoordinateTransform(
            OSM_CRS, WGS84_CRS, QgsProject.instance()
        )
        point_4326 = transform.transform(point)
        self.coord_label.setText(
            f"{point_4326.y():.5f}N, {point_4326.x():.5f}E"
        )

    # --- Sprzatanie ---

    def closeEvent(self, event):
        if hasattr(self, "wfs_thread") and self.wfs_thread.isRunning():
            self.wfs_thread.terminate()
            self.wfs_thread.wait()
        if self.powiaty_layer:
            try:
                QgsProject.instance().removeMapLayer(self.powiaty_layer.id())
            except Exception:
                pass
        if self.osm_layer:
            try:
                QgsProject.instance().removeMapLayer(self.osm_layer.id())
            except Exception:
                pass
        super().closeEvent(event)

    # --- Publiczne API ---

    def get_selected_powiat(self):
        """Zwraca aktualnie wybrany feature powiatu (lub None)."""
        return self.selected_powiat

    def get_selected_geometry(self):
        """Zwraca geometrie wybranego powiatu (lub None)."""
        if self.selected_powiat:
            return self.selected_powiat.geometry()
        return None
