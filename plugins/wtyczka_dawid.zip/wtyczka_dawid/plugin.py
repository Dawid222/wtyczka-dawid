from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtGui import QIcon
import os


class WtyczkaDawid:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.dialog = None

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, "icon.png")
        self.action = QAction(
            QIcon(icon_path) if os.path.exists(icon_path) else QIcon(),
            "Wtyczka Dawid",
            self.iface.mainWindow(),
        )
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&Wtyczka Dawid", self.action)

    def unload(self):
        self.iface.removePluginMenu("&Wtyczka Dawid", self.action)
        self.iface.removeToolBarIcon(self.action)
        if self.dialog:
            self.dialog.close()
            self.dialog = None

    def run(self):
        from .map_dialog import MapDialog

        if self.dialog is None:
            self.dialog = MapDialog(self.iface, self.iface.mainWindow())
        self.dialog.show()
        self.dialog.raise_()
